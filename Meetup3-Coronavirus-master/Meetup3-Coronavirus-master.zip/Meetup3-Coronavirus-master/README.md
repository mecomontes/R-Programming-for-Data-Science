# Meetup3-Coronavirus
En este repositorio se encuentran todos los archivos del taller de exploración de bases de datos del Coronavirus usando R. El link de la presentación del taller es: https://rpubs.com/RLadiesMedellin/609925
